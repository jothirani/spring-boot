package com.example.ToDoApp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ToDoConfig {

 
 @Bean
 
 public ToDoService todoBean() {
     
     return new ToDoService();
 }
}