package com.example.ToDoApp;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class ToDoAppApplication {

	public static void main(String[] args) {
	
		 AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ToDoConfig.class);

	     ToDoService todo = context.getBean("todoBean", ToDoService.class);
	    
	     todo.ToDoApp();
	}

}
