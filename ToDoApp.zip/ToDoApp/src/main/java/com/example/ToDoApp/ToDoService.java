package com.example.ToDoApp;



import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class ToDoService {
	
	public void frame()
	{
		JFrame frame = new JFrame("TO DO LIST");
        
        
        String[][] data = {{"01", "rani", "18"}, {"02", "punitha", "20"}, {"03", "rathan", "18"}, {"04", "mark", "25"}};
        String[] column = {"ID", "Name", "Age"};
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        
        JTable jt = new JTable(data, column);
        JScrollPane sp = new JScrollPane(jt);       
        
        frame.add(sp);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(screenSize.width, screenSize.height);
	}

  
}
