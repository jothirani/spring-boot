package com.example.ToDoApp;



import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;





public class ToDoService {
	private JFrame frame;
    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextField taskInput;
    private ArrayList<String> tasks;
    private GraphicsDevice device;

    public void ToDoApp() {
       
        tasks = new ArrayList<>();
        GraphicsEnvironment graphics =
        	      GraphicsEnvironment.getLocalGraphicsEnvironment();
        taskListModel = new DefaultListModel<>();
        device = graphics.getDefaultScreenDevice();

       
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

       
        JLabel headerLabel = new JLabel("Todo List", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(headerLabel, BorderLayout.NORTH);

       
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        taskInput = new JTextField(20);
        JButton addButton = new JButton("Add Task");

        inputPanel.add(taskInput);
        inputPanel.add(addButton);
        frame.add(inputPanel, BorderLayout.SOUTH);

       
        taskList = new JList<>(taskListModel);
        JScrollPane scrollPane = new JScrollPane(taskList);

        frame.add(scrollPane, BorderLayout.CENTER);

       
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton deleteButton = new JButton("Delete Task");
        JButton clearButton = new JButton("Clear All");

        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        frame.add(buttonPanel, BorderLayout.EAST);

       
        
        addButton.addActionListener(new ActionListener() {
        	   public void actionPerformed(ActionEvent e) {
        		   String task = taskInput.getText().trim();
        	        if (!task.isEmpty()) {
        	            tasks.add(task);
        	            taskListModel.addElement(task);
        	            taskInput.setText("");
        	        } else {
        	            JOptionPane.showMessageDialog(frame, "Please enter a task!");
        	        }
        	   }
        	});
        deleteButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				int selectedIndex = taskList.getSelectedIndex();
		        if (selectedIndex != -1) {
		            tasks.remove(selectedIndex);
		            taskListModel.remove(selectedIndex);
		        } else {
		            JOptionPane.showMessageDialog(frame, "Please select a task to delete!");
		        }
				
			}
		});
        clearButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				 tasks.clear();
			        taskListModel.clear();
				
			}
		});

      
        frame.setVisible(true);
        device.setFullScreenWindow(frame);
    }

  
}
