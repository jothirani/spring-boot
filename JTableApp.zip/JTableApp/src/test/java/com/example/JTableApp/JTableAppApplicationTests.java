package com.example.JTableApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JTableAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
