package com.example.JTableApp;


import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class JTableApp {

    public void JTableAppTest() {
    	  JFrame frame = new JFrame("STUDENT LIST");
	        
	       
	        String[][] data = {{"01", "john", "18"}, {"02", "vinayak", "20"}, {"03", "rani", "18"}, {"04", "pavithra", "25"}};
	        String[] column = {"ID", "Name", "Age"};
	        
	       
	        JTable jt = new JTable(data, column);
	        JScrollPane sp = new JScrollPane(jt);       
	        GraphicsEnvironment graphics =
	        GraphicsEnvironment.getLocalGraphicsEnvironment();
	        GraphicsDevice device = graphics.getDefaultScreenDevice();
	        frame.add(sp);
	        frame.pack();
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setVisible(true);
	        device.setFullScreenWindow(frame);
       
    } 
  
}
