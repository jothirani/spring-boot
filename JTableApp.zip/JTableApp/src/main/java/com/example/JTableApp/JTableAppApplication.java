package com.example.JTableApp;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



@SpringBootApplication
public class JTableAppApplication {

	public static void main(String[] args) {
		 AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

	     JTableApp tab = context.getBean("TabBean", JTableApp.class);
	    
	     tab.JTableAppTest();
	}

}
